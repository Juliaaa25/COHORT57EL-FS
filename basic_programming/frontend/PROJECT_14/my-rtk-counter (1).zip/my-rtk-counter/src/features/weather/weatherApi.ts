import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import type { WeatherResponse } from "./types/types";

const apiKey = "3603bb385cba1812ea388450e7b58c94";

export const weatherApi = createApi({
    reducerPath: "weatherApi",
    baseQuery: fetchBaseQuery({
        baseUrl: "https://api.openweathermap.org/data/2.5/",
    }),
//   В этот момент RTK Query внутри себя строит объект API, который:
//  хранит редьюсер
//  создаёт middleware
//  готовит кеш
// генерирует хуки (ВАЖНО!)
    endpoints:(builder) => ({
        getWeather:builder.query<WeatherResponse, string>({
        // RTK Query автоматически создаёт хук с названием:
        // use + название эндпоинта + Query
        // useGetWeatherQuery
            query: (city) => 
            `weather?q=${city}&appid=${apiKey}&units=metric`    
        }),
    })
});
export const { useGetWeatherQuery } = weatherApi


// Компонент → dispatch(action) → редьюсер

// 🟩 1. RTK (Redux Toolkit) — когда пишем всё вручную

// Используем:

// createSlice

// createAsyncThunk

// extraReducers

// dispatch

// useSelector

// Как работает:

// Создаём asyncThunk для запроса

// Делаем axios.get внутри

// Прописываем loading / error / data вручную

// Создаём slice и редьюсер

// Описываем extraReducers

// Вызываем dispatch(fetchWeather())

// Читаем данные из Redux через useSelector

// Минусы:

// 🚫 Много кода

// 🚫 Нужно вручную описывать стейты загрузки, ошибок

// 🚫 Нужно самому управлять кешем

// 🚫 Каждое действие — extraReducers

// 🚫 Нужно вручную вызывать dispatch

// Плюсы:

// ✔ Полный контроль

// ✔ Понятен новичкам (пошаговая логика)

// ✔ Подходит для локальных не-API задач

// 🟦 2. RTK Query — когда всё делает библиотека

// Используем:

// createApi

// fetchBaseQuery

// builder.query

// автогенерируемые хуки: useGetWeatherQuery, useLazyGetWeatherQuery

// Как работает:

// Описываем API внутри createApi

// RTK Query сам:

// делает запрос

// кэширует результат

// выдает статус загрузки

// сохраняет ошибку

// обновляет данные

// Из weatherApi автоматически создаётся хук для компонента

// В компоненте:
// const { data, error, isLoading } = useGetWeatherQuery(city);

// Или вручную по кнопке:
// const [trigger, result] = useLazyGetWeatherQuery();
// trigger(city);

// Плюсы:

// ✔ На 70–90% меньше кода

// ✔ Нет slice, thunk, extraReducers

// ✔ Автогенерация хуков

// ✔ Автокэширование

// ✔ Автоматический рефетч

// ✔ Управление запросами встроено в библиотеку

// ✔ Меньше ошибок

// Минусы:

// ⚠ Студенты сначала путаются в skip, refetch, lazy

// ⚠ Нужно объяснить middleware

// ⚠ Нельзя использовать без Redux store