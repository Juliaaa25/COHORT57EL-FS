export default function Home(): JSX.Element {
	return <div>Home</div>
}
